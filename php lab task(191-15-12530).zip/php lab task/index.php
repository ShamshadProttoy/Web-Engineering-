<?php
$con = mysqli_connect('localhost', 'root', '');
if (!$con) {
    echo "Not connected to the server";
}

if (!mysqli_select_db($con, 'web')) {
    echo "Database not connected";
}

$name = $_POST['User_Name'];
$email = $_POST['User_Email'];

$sql = "INSERT INTO user(name, email) VALUES('$name', '$email')";

if (!mysqli_query($con, $sql)) {
    echo "Not inserted";
} else {
    echo "Inserted Successfully";
}
