function demo(){
    var result=document.getElementById("result");

    var dateTime= new Date();
    var hours=dateTime.getHours();
    var minutes=dateTime.getMinutes();
    var sec=dateTime.getSeconds();

    var Watch=hours+":"+minutes+":"+sec;
    result.innerHTML=Watch;


}

setInterval(demo,3000);