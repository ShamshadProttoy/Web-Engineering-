<?php
$con = mysqli_connect('localhost', 'root', '');
if (!$con) {
    echo "Not connected to the server";
}

if (!mysqli_select_db($con, 'web')) {
    echo "Database not connected";
}

$Old_Email = $_POST['Old_Email'];
$New_Email = $_POST['New_Email'];

$sql = "UPDATE user SET email='$New_Email' WHERE email='$Old_Email'";

if (!mysqli_query($con, $sql)) {
    echo "Not Updated";
} else {
    echo "Updated Successfully";
}
?>